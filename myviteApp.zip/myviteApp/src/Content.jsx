const Content=()=>{    //functional component
    return( 
        <>         
        <div>          
            
        </div>
        </>
    )
}
export default Content;