const fs = require('fs');
const path = require('path');
const jsonData = JSON.parse(fs.readFileSync(path.join(__dirname,"..","Model","product.json"),"utf-8"))

const getProducts = (req, res) => {
    try {
        res.json({
            status: "success",
            count: jsonData.length,
            data: {
                products: jsonData
            },
        });
    } catch (error) {
        res.status(500).json({
            status: "error",
            message: "Failed to fetch products",
            error: error.message
        });
    }
}

const idvalidator = (req,res,next,value)=>{
    value = value*1 
    const item = jsonData.find((item)=>item.id === value)
    if(!item){
       return  res.status(400).json({
            status:"failed",
            message : "no prodcuts found"
        })
    }
    next()
}

const getProduct = (req,res)=>{
    console.log("Yes")
    let id = req.params.id*1;
    const data = jsonData.find((i)=>i.id==id)
    res.json({
        status:"success",
        data:data
    })
}

const addedProduct = (req,res)=>{
    const id = jsonData.length + 1
    // created new id and added
    const newProduct = {
        id:id,
        ...req.body
    };
    // to push in jsonData
    jsonData.push(newProduct)
    console.log(jsonData)
    // to convert the JavaScript object into JSON format
    fs.writeFileSync(path.join(__dirname,"..","Model","product.json"),JSON.stringify(jsonData),()=>{})
    res.json({
        status : "fulfilled",
        count : jsonData.length,
        data:jsonData
    })
}

const deletedProduct = (req,res)=>{
    // *1 - the string will be converted to number
    let id = req.params.id*1
    let deletedJson = jsonData.filter((i)=>(i.id!==id));
    fs.writeFile(path.join(__dirname,"..","Model","product.json"),JSON.stringify(deletedJson),()=>{})
    res.status(204)
    res.json();
}


const updatedProduct =(req,res)=>{
        let id = req.params.id*1
        let updateProd = jsonData.find((i)=>i.id===id)
        let index = jsonData.indexOf(updateProd)
        jsonData[index]=Object.assign(updateProd,req.body)
        fs.writeFileSync(path.join(__dirname,"..","Model","product.json"),JSON.stringify(jsonData))
        res.json({})
        console.log(jsonData[index]);
}


const updateProduct = (req,res)=>{
    let id = req.params.id*1
    let updateProd = jsonData.find((i)=>i.id===id)
    let index = jsonData.indexOf(updateProd)
    jsonData[index]=req.body
    res.status(200).json({status:"put updated"})
    fs.writeFileSync(path.join(__dirname,"..","Model","product.json"),JSON.stringify(jsonData))
    res.json({})
    console.log(jsonData[index]);
}

const validate = (req,res,next)=>{
let body = req.body
let headers = req.headers 

if(headers.token!=="pass"){
    return res.status(400).json({
        status : "fail" ,
        message : "unauth access"
    })
}
//having name and count means true        
if(!body.name || !body.count){
    return res.status(401).json({
        status : "fail" ,
        message : "bad request"
    })
}
     next()        
}

module.exports = {getProduct,getProducts,addedProduct,deletedProduct,updateProduct,updatedProduct,validate,idvalidator} 