const {getProducts,getProduct,deletedProduct,updateProduct,updatedProduct,addedProduct,validate,idvalidator} =require("../routeHandler/productFuntions")
const express = require("express")
const productRoutes = express.Router()
productRoutes.param("id",idvalidator)

productRoutes.route("/").get(getProducts).post(validate,addedProduct)

productRoutes.route("/:id").get(getProduct).delete(deletedProduct).patch(updatedProduct).put(updateProduct)

module.exports = productRoutes 