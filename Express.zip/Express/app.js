const express = require("express")
const morgan = require("morgan")
const dotenv = require("dotenv")
const productRoutes = require("./routes/productRoutes")
dotenv.config({path:"./config.env"})
const app = express()
app.use(express.json())

app.use(morgan("dev"))

app.use("/api/v1/products",productRoutes)

// app.get("/api/v1/products/:id" , getProduct)
// app.post("/api/v1/products" , addedProduct)
// app.delete ("/api/v1/products/:id" , deletedProduct)
// app.patch("/api/v1/products/:id" , updatedProduct)
// app.put("/api/v1/products/:id" , updateProduct

module.exports = app 