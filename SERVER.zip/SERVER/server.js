const http = require("http")
const url = require("url")

const server = http.createServer((req,res)=>{
    let {query} = url.parse(req.url,true)
    console.log(query.id)
    let{id,name} = query
    console.log(id)
    console.log(name)
});

server.listen(3000,()=>{console.log("heyy")}) ;  