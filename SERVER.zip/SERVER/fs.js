const fs = require("fs");
const { log } = require("util");


//createfile it not exists , if content is changed it overrides
// fs.writeFile("sample.txt","hello world" ,(err)=>{})

//content joins with first content 
// fs.appendFile("sample.txt","\nusing appendfile ",(err)=>{})
// try {
    
// fs.readFile("sample.tx",(err,data)=>{
//     if(err) throw err
//     console.log(data.toString()); 
// })
// } catch (error) {
//     console.log(error.message);   
//  }
// process.on("uncaughtException",(err)=>{
//     console.log(err.message);
// })

//deletes the file 
// fs.unlink("sample.txt",()=>{})

//create folder
// fs.mkdir("folder",()=>{})

//remove folder
// fs.rmdir("folder",()=>{})


// Event-loop 
//file read operations happens in background
// fs.readFile("text.txt",(err,data)=>{
//     console.log(data.toString());
// })

// const filedata =fs.readFileSync("text.txt","utf8")
// console.log(filedata);

// console.log("hello all") ;

// callback hell
// fs.writeFileS("firstfile.txt","The sample file is created2" , ()=>{
//     fs.appendFile("firstfile.txt","appended data" , ()=>{
//         fs.readFile("firstfile.txt",(err,data)=>{
//             console.log(data.toString());  
//         })
//     })
// })

fs.writeFileSync("sample2.txt","original data");
fs.appendFileSync("sample2.txt","append")
const filedata2 =fs.readFileSync("sample2.txt","utf8")
console.log(filedata2)
