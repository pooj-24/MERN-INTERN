import React from 'react'
import {useRef, useState} from 'react'
function todo() {
    const [data, setData] = useState([])
    const refer = useRef()
    function handleClick()
    {
        setData([...data, {task:refer.current.value}])
        refer.current.value = ""
    }
  return (
    <div>
        <input ref = {refer} type="text" name = "" id= ""/>
        <button onClick ={handleClick}>Save</button>
        {data.map(i => <li>{i.task}</li>)}
    </div>
  )
}

export default todo