import React from 'react';
import { useState } from 'react';

function Form() {
  const [data, setData] = useState({
    email:"example@gmail.com", 
    pass:""})
  function handleChange(e){
    setData({...data, email:e.target.value});
  }
  console.log(data);
  return (
    <div className="flex justify-center items-center min-h-screen bg-red-500">
      <div className="bg-white p-10 rounded-lg shadow-lg w-80">
      <form action="">
        <div className="mb-4">
          <label htmlFor="email" className="block text-gray-700 font-bold mb-2">Email</label>
            <input  value = {data.email} onChange={ (e) => handleChange(e)} type="text" id="email" className="w-100 p-2 border border-gray-300 rounded-lg "/>
        </div>
        <div className="mb-6">
        <label htmlFor="password" className="block text-gray-700 font-bold mb-2"> Password </label>
        <input onChange={(e) => setData({...data, pass:e.target.value})} value={data.pass
          
        } type="password" id="password" className="w-100 p-2 border border-gray-300 rounded-lg "/>
        </div>
        <div className="text-center">
            <button type="submit" className="w-100 bg-red-600 text-white p-3 rounded-lg font-bold"> Submit </button>
        </div>
        </form>
      </div>
    </div>
  );
}

export default Form;
