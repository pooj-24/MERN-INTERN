// // // 1. functional components
// // // const Header=()=>{
// // //     // let data=["Apple","Banana","Fig"]
// // //     return(
// // //         <div>
// // //             {/* {data.map((i,k) => {
// // //                 return(
// // //                     <li key={k}>{i}</li>
// // //                 )
// // //             })} */}


// // //         </div>
// // //     )
// // // }
// // // export {Header};

// // // import React from 'react'

// // // function Header() {
// // //   return (
// // //     <div>Header</div>
// // //   )
// // // }

// // // function Header1() {
// // //     return (
// // //       <div>Header</div>
// // //     )
// // //   }
// // // export {Header}

// // //conditional rendering 
// // const Header = () => {
// //     // if(true)
// //     // {
// //     //     return(
// //     //         <h1>It's for client</h1>
// //     //     )
// //     // }
// //     // else{

// //     // }
// //     let data=[]
// //     return
// //     (
// //         <div>
            
// //                 {/* {!data.length>0 &&  
// //                     <h1>Yeah!</h1>
// // } */}

// //         { data.length>0?<h1>Yes there is Data</h1>:<h1>No More Data</h1>}        
// //         </div>
// //                 )
// //             }
        
// // export {Header}

// /*import React from 'react';

// const Header = () => {
//     const data = [1,2,3,4,5]

//     return (
//         <div>
//             {data.map((i,k)=>
//             {
//                 return(
//                     <li key={k}>{i}</li>
//                 )
//             }
//         )}
//         </div>
//     )
// };

// export default Header;*/
// // import React from 'react'
// // const Header = () => {
//     // function curry(a){
//     //     return (b) =>{
//     //         console.log(a+b);
//     //     }
//     // }

//     // const curry=(a)=>(b)=>a+b;
//     //  console.log(curry(10)(40));

// //     function greet(greeting, symbol){
// //         const {name,age} = this;
// //         console.log(name,age);
// //     }


// //     const user = {name:"john", age:27}

// //     greet.call(user, "hello", "!");

// //   return (
// //     <div>
// //     </div>
// //   )
// // }

// // export default Header;

// import React from "react";

// const Header = () => {
//   return (
//     <header className="bg-primary text-white w-screen fixed-top row">
//       <h1 className="display-4 d-md-inline text-center text-md-start col-12 col-md-6">
//         My Blog
//       </h1>
//       <ul className="list-inline col-12 col-md-6 list-none d-flex justify-content-around justify-content-md-end gap-5 align-items-center mt-4">
//         <li className="list-inline-item">
//           <a className="text-white text-decoration-none" href="#">
//             Home
//           </a>
//         </li>
//         <li className="list-inline-item">
//           <a className="text-white text-decoration-none" href="#">
//             About
//           </a>
//         </li>
//         <li className="list-inline-item">
//           <a className="text-white text-decoration-none" href="#">
//             Contact
//           </a>
//         </li>
//       </ul>
//     </header>
//   );
// };

// export default Header;

import React from "react";

const Header = () => {
  return (
    <header className="bg-primary text-white w-screen fixed-top row">
      <h1 className="display-4 d-md-inline text-center text-md-start col-12 col-md-6">
        My Blog
      </h1>
      <ul className="list-inline col-12 col-md-6 list-none d-flex justify-content-around justify-content-md-end gap-5 align-items-center mt-4">
        <li className="list-inline-item">
          <a className="text-white text-decoration-none" href="#">
            Home
          </a>
        </li>
        <li className="list-inline-item">
          <a className="text-white text-decoration-none" href="#">
            About
          </a>
        </li>
        <li className="list-inline-item">
          <a className="text-white text-decoration-none" href="#">
            Contact
          </a>
        </li>
      </ul>
    </header>
  );
};

export {Header};

