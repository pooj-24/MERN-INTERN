// // import React from 'react'
// // import { useState , useRef } from 'react'
// // import { useContext } from 'react';
// // import MyContext from './ContextAPI';

// // function Footer() {
// //    const refer = useRef()
// //   // const [data , setData] = useState(0);
// //    function handleClick() {
// //    refer.current.focus()
// //    }

// //    let dataFromGlobal = useContext(MyContext)
    
// //   return (
// //     <div>
// //         {dataFromGlobal}
        
// //         <input ref ={refer}
// //         type="text"/>
// //         <button onClick = {handleClick}> focus</button>

// //     </div>
   
// //   )
// // }

// // export {Footer}

// import React from "react";

// const Footer = () => {
//   return (
//     <footer className="bg-dark text-white text-center py-3 mt-4">
//       <p>&copy; 2025 My Blog. All rights reserved.</p>
//     </footer>
//   );
// };

// export default Footer;

import React from "react";

const Footer = () => {
  return (
    <footer className="bg-dark text-white text-center py-3 mt-4">
      <p>&copy; 2025 My Blog. All rights reserved.</p>
    </footer>
  );
};

export default Footer;

