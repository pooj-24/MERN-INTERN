import React from 'react'

function contact() {
  return (
    <div>contact</div>
  )
}

export default contact