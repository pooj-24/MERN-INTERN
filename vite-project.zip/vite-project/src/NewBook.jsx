import React from 'react'

function NewBook() {
  return (
    <div>NewBook</div>
  )
}

export default NewBook