const express = require("express")
const path = require("path")
const app = express()
const {engine} = require("express-handlebars")

app.use(express.static(path.join(__dirname,"public"))) //static middleware - it is going to return middleware

app.set("view engine","hbs") //setting view engine to pug
app.engine("hbs",engine({extname:"hbs",defaultLayout:false}))

app.get("/home",(req,res)=>{
    const datachunk = "Nithya"
    let array = [1,2,3,4,5]
    res.render("index",{datachunk, array})//render the pug file
})

app.get("/contact",(req,res)=>{
    res.render("contact")
})

app.get("/about",(req,res)=>{
    let array = [1,2,3,4,5]
    res.render("about",{array})
})

app.listen(3000,()=>{
    console.log("server is running"); 
}) 