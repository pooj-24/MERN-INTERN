import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { addPost } from "./Slice/blogslice";
import { useNavigate } from "react-router-dom";

function CreatePost() {
  const [author, setAuthor] = useState("");
  const [data, setData] = useState("");
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleSubmit = () => {
    if (author.trim() && data.trim()) {
      const newPost = {
        id: Date.now(),
        author,
        data,
      };
      dispatch(addPost(newPost));
      setAuthor("");
      setData("");
      alert("Post added successfully!");
      navigate("/posts");
    } else {
      alert("Both fields are required!");
    }
  };

  return (
    <div>
      <label htmlFor="authordata">Author: </label>
      <input
        value={author}
        onChange={(e) => setAuthor(e.target.value)}
        type="text"
        id="authordata"
      />
      <label htmlFor="data">Data: </label>
      <input
        value={data}
        onChange={(e) => setData(e.target.value)}
        type="text"
        id="data"
      />
      <button onClick={handleSubmit}>Submit</button>
    </div>
  );
}

export default CreatePost;