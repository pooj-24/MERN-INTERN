const mongoose = require("mongoose")
const cust = require("./schema")
async function db() {
   try {
    await mongoose.connect("mongodb://localhost:27017/customer")
   console.log("db connected");  
}
catch (error) {
    console.log("error on connection db");
   }

// const newCustomer = new cust({
//       name:'nithya',
//       age:21,
//       address :{
//         pincode:123456,
//         state:"TN"
//       },
//       hobbies:["dancing","sleeping"]
//    })
//    newCustomer.save()


// const newCustomer =await cust.create({
//     name:'alice',
//     age:25,
//     friend:"6798619c40ed3e1ac20df367",
//     address :{
//         pincode:123456,
//         state:"TN"
//       },
//       email:"ALICE@GMAIL.COM",
//     hobbies:["dancing","sleeping"]
// })
// newCustomer.save()
// console.log(newCustomer);

const customerData = await cust.findById("67986ec8511db425b589cd6d").populate("friend")
console.log(customerData);

}
db() 